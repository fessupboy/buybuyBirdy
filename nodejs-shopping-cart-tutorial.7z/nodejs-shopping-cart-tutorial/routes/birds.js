var express = require('express');
var router = express.Router();
var Birds = require('../models/birds');

router.use(function (req, res, next) {
    res.locals.login = req.isAuthenticated();
    next();
});

router.get('/birds', function (req, res, next) {
    Birds.find(function (err, docs) {
        var productChunks = [];
        var chunkSize = 3;
        for (var i = 0; i < docs.length; i += chunkSize) {
            productChunks.push(docs.slice(i, i + chunkSize));
        }
        res.render('animals3/birds', {title: 'Birds Page', birds: productChunks});
    });
});

module.exports = router;
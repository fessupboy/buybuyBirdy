var express = require('express');
var router = express.Router();
var Dogs = require('../models/dogs');

router.use(function (req, res, next) {
    res.locals.login = req.isAuthenticated();
    next();
});

router.get('/dogs', function (req, res, next) {
    Dogs.find(function (err, docs) {
        var productChunks = [];
        var chunkSize = 3;
        for (var i = 0; i < docs.length; i += chunkSize) {
            productChunks.push(docs.slice(i, i + chunkSize));
        }
        res.render('animals/dogs', {title: 'Dogs Page', dogs: productChunks});
    });
});

module.exports = router;
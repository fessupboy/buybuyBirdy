var express = require('express');
var router = express.Router();
var Cats = require('../models/cats');

router.use(function (req, res, next) {
    res.locals.login = req.isAuthenticated();
    next();
});

router.get('/cats', function (req, res, next) {
    Cats.find(function (err, docs) {
        var productChunks = [];
        var chunkSize = 3;
        for (var i = 0; i < docs.length; i += chunkSize) {
            productChunks.push(docs.slice(i, i + chunkSize));
        }
        res.render('animals2/cats', {title: 'Cats Page', cats: productChunks});
    });
});

module.exports = router;
var express = require('express');
var router = express.Router();
var Reptiles = require('../models/reptiles');

router.use(function (req, res, next) {
    res.locals.login = req.isAuthenticated();
    next();
});

router.get('/reptiles', function (req, res, next) {
    Reptiles.find(function (err, docs) {
        var productChunks = [];
        var chunkSize = 3;
        for (var i = 0; i < docs.length; i += chunkSize) {
            productChunks.push(docs.slice(i, i + chunkSize));
        }
        res.render('animals4/reptiles', {title: 'Reptiles Page', reptiles: productChunks});
    });
});

module.exports = router;
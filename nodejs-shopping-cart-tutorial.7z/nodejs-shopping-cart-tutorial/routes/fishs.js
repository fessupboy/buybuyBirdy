var express = require('express');
var router = express.Router();
var Fishs = require('../models/fishs');

router.use(function (req, res, next) {
    res.locals.login = req.isAuthenticated();
    next();
});

router.get('/fishs', function (req, res, next) {
    Fishs.find(function (err, docs) {
        var productChunks = [];
        var chunkSize = 3;
        for (var i = 0; i < docs.length; i += chunkSize) {
            productChunks.push(docs.slice(i, i + chunkSize));
        }
        res.render('animals5/fishs', {title: 'Fishs Page', fishs: productChunks});
    });
});

module.exports = router;